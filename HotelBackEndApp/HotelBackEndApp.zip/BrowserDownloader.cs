﻿using Microsoft.Playwright;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace HotelBackEndApp
{
    public class BrowserDownloader
    {
        private string _downloadPath;
        private IBrowser? _browser;
        private IPlaywright? _playwright;
        private IBrowserContext? _context;
        private string _url;
        private string _detailsurl;
        private string _filedownloadurl;
        private string _user;
        private string _password;
        private string _startdate;
        private string _enddate;

        public BrowserDownloader(string downloadPath,
            string startdate, string enddate,
            string url = "https://sp.fuioupay.com/login",
            string detailsurl = "https://sp.fuioupay.com/count/commodity/sales/details/details",
            string filedownloadurl = "https://sp.fuioupay.com/download/doc",
            string user = "MX4351344",
            string password = "719720")
        {
            _downloadPath = downloadPath;
            _startdate = startdate;
            _enddate = enddate;
            _url = url;
            _detailsurl = detailsurl;
            _filedownloadurl = filedownloadurl;
            _user = user;
            _password = password;
            Directory.CreateDirectory(_downloadPath); // 确保目录存在
        }

        public async Task<string?> DownloadFileAsync()
        {
            // 创建 Playwright 实例
            _playwright ??= await Playwright.CreateAsync();
            _browser ??= await _playwright.Firefox.LaunchAsync(new BrowserTypeLaunchOptions
            {
                Headless = false,  // 让浏览器显示出来
                SlowMo = 500 // 放慢操作，避免页面加载过快
            });

            _context = await _browser.NewContextAsync(new BrowserNewContextOptions
            {
                ViewportSize = ViewportSize.NoViewport, // 让窗口使用操作系统默认大小（接近最大化）
                JavaScriptEnabled = true, // 确保 JS 是启用的
                Locale = "zh-CN",
                ExtraHTTPHeaders = new Dictionary<string, string>
                {
                    ["Accept-Language"] = "zh-CN,cn;q=0.9"
                },
                RecordVideoDir = Path.Combine(Directory.GetCurrentDirectory(), "videos"), // 指定到更快的 SSD 目录
                RecordVideoSize = new RecordVideoSize { Width = 1920, Height = 1080 } // 提高视频分辨率
            });

            var page = await _context.NewPageAsync();
            try
            {
                // 让窗口最大化
                await page.EvaluateAsync("window.moveTo(0, 0); window.resizeTo(screen.width, screen.height);");

                await page.GotoAsync(_url, new PageGotoOptions { WaitUntil = WaitUntilState.NetworkIdle });
                await page.WaitForTimeoutAsync(2000);

                // 登录
                await page.GetByPlaceholder("请输入登录帐号").FillAsync(_user);
                await page.GetByPlaceholder("请输入登录密码").FillAsync(_password);
                await page.ClickAsync("text=登 录");

                await page.WaitForTimeoutAsync(2000);
                await page.GotoAsync(_detailsurl);
                await page.WaitForSelectorAsync("input[placeholder='开始日期']");

                // 解除 readonly 限制
                await page.EvaluateAsync("document.querySelectorAll('input[placeholder=\"开始日期\"], input[placeholder=\"结束日期\"]').forEach(el => el.removeAttribute('readonly'))");

                // 选择日期
                await page.GetByPlaceholder("开始日期").FillAsync(_startdate);
                await page.GetByPlaceholder("结束日期").FillAsync(_enddate);

                await page.WaitForTimeoutAsync(1000);
                await page.GetByRole(AriaRole.Button, new() { Name = "导出excel" }).ClickAsync();

                var successLocator = page.Locator("xpath=//div[text()='导出任务记录成功!']");
                await successLocator.WaitForAsync(new LocatorWaitForOptions { Timeout = 5000 });

                // 导航到下载页面
                await page.GotoAsync(_filedownloadurl);
                await page.WaitForTimeoutAsync(1000);

                // 等待下载
                var waitForDownloadTask = page.WaitForDownloadAsync();
                await page.Locator(".el-table__fixed-body-wrapper > .el-table__body > tbody > tr > .el-table_1_column_10 > .cell > div > button").First.ClickAsync();
                var download = await waitForDownloadTask;

                // 保存下载的文件
                string filePath = Path.Combine(_downloadPath, download.SuggestedFilename);
                await download.SaveAsAsync(filePath);

                return filePath;
            }
            finally
            {
                await _browser.CloseAsync();
            }
        }

        public async Task CloseBrowserAsync()
        {
            if (_browser != null)
            {
                await _browser.CloseAsync();
            }
            _playwright?.Dispose();
        }
    }
}
